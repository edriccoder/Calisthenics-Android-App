package com.example.gymapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;

import java.util.List;

public class exfocus_adapter extends ArrayAdapter<Exercise> {

    private Context mContext;
    private List<Exercise> mExerciseList;

    public exfocus_adapter(Context context, List<Exercise> exerciseList) {
        super(context, 0, exerciseList);
        mContext = context;
        mExerciseList = exerciseList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(mContext).inflate(R.layout.list_item, parent, false);
        }

        Exercise currentExercise = mExerciseList.get(position);

        ImageView imageView = listItemView.findViewById(R.id.imageView);
        TextView exerciseNameTextView = listItemView.findViewById(R.id.exerciseNameTextView);
        TextView descriptionTextView = listItemView.findViewById(R.id.descriptionTextView);
        TextView difficultyTextView = listItemView.findViewById(R.id.difficultyTextView);


        exerciseNameTextView.setText(currentExercise.getExerciseName());
        descriptionTextView.setText(currentExercise.getDescription());
        difficultyTextView.setText("Difficulty: " + currentExercise.getDifficulty());


        if (!currentExercise.getImageUrl().isEmpty()) {

            if (currentExercise.getImageUrl().endsWith(".gif")) {

                Glide.with(getContext()).asGif().load(currentExercise.getImageUrl()).into(imageView);
            } else {

                Glide.with(getContext())
                        .load(currentExercise.getImageUrl())
                        .transition(DrawableTransitionOptions.withCrossFade())
                        .into(imageView);
            }
        } else {

            imageView.setImageResource(R.drawable.dumbell);
        }

        return listItemView;
    }
}
