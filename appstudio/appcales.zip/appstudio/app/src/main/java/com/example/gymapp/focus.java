package com.example.gymapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.vishnusivadas.advanced_httpurlconnection.PutData;

public class focus extends AppCompatActivity {
    Button but1, but2, but3, but4, but5, but6, but7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_focus);

        but1 = (Button) findViewById(R.id.but1);
        but2 = (Button) findViewById(R.id.but2);
        but3 = (Button) findViewById(R.id.but3);
        but4 = (Button) findViewById(R.id.but4);
        but5 = (Button) findViewById(R.id.but5);
        but6 = (Button) findViewById(R.id.but6);
        but7 = (Button) findViewById(R.id.but7);

        String username = signups.Globals.username;
        String fullbody, arm, chest, abs, legs, backbody, cardio;
        fullbody = "Full Body";
        arm = "Arm";
        chest = "Chest";
        abs = "Abs";
        legs = "Legs";
        backbody = "Back";
        cardio = "Cardio";

        but1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Handler handler = new Handler(Looper.getMainLooper());
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        String[] field = new String[2];
                        field[0] = "username";
                        field[1] = "focusbody";

                        String[] data = new String[2];
                        data[0] = username;
                        data[1] = fullbody;

                        PutData putData = new PutData("http://192.168.1.28/calestechsync/createFocusGoal.php/", "POST", field, data);

                        if (putData.startPut()) {
                            if (putData.onComplete()) {
                                String result = putData.getResult();
                                if (result.equals("Focus Goal Created Successfully")) {

                                    Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                                } else {

                                    Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                                }
                            }
                        } else {

                            Toast.makeText(getApplicationContext(), "Failed to connect", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });

        but2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Handler handler = new Handler(Looper.getMainLooper());
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        String[] field = new String[2];
                        field[0] = "username";
                        field[1] = "focusbody";

                        String[] data = new String[2];
                        data[0] = username;
                        data[1] = arm;

                        PutData putData = new PutData("http://192.168.1.28/calestechsync/createFocusGoal.php/", "POST", field, data);

                        if (putData.startPut()) {
                            if (putData.onComplete()) {
                                String result = putData.getResult();
                                if (result.equals("Focus Goal Created Successfully")) {

                                    Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                                } else {

                                    Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                                }
                            }
                        } else {

                            Toast.makeText(getApplicationContext(), "Failed to connect", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });

        but3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Handler handler = new Handler(Looper.getMainLooper());
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        String[] field = new String[2];
                        field[0] = "username";
                        field[1] = "focusbody";

                        String[] data = new String[2];
                        data[0] = username;
                        data[1] = chest;

                        PutData putData = new PutData("http://192.168.1.28/calestechsync/createFocusGoal.php/", "POST", field, data);

                        if (putData.startPut()) {
                            if (putData.onComplete()) {
                                String result = putData.getResult();
                                if (result.equals("Focus Goal Created Successfully")) {

                                    Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                                } else {

                                    Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                                }
                            }
                        } else {

                            Toast.makeText(getApplicationContext(), "Failed to connect", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });

        but4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Handler handler = new Handler(Looper.getMainLooper());
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        String[] field = new String[2];
                        field[0] = "username";
                        field[1] = "focusbody";

                        String[] data = new String[2];
                        data[0] = username;
                        data[1] = abs;

                        PutData putData = new PutData("http://192.168.1.28/calestechsync/createFocusGoal.php/", "POST", field, data);

                        if (putData.startPut()) {
                            if (putData.onComplete()) {
                                String result = putData.getResult();
                                if (result.equals("Focus Goal Created Successfully")) {

                                    Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                                } else {

                                    Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                                }
                            }
                        } else {

                            Toast.makeText(getApplicationContext(), "Failed to connect", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });

        but5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Handler handler = new Handler(Looper.getMainLooper());
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        String[] field = new String[2];
                        field[0] = "username";
                        field[1] = "focusbody";

                        String[] data = new String[2];
                        data[0] = username;
                        data[1] = legs;

                        PutData putData = new PutData("http://192.168.1.28/calestechsync/createFocusGoal.php/", "POST", field, data);

                        if (putData.startPut()) {
                            if (putData.onComplete()) {
                                String result = putData.getResult();
                                if (result.equals("Focus Goal Created Successfully")) {

                                    Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                                } else {

                                    Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                                }
                            }
                        } else {

                            Toast.makeText(getApplicationContext(), "Failed to connect", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });

        but6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Handler handler = new Handler(Looper.getMainLooper());
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        String[] field = new String[2];
                        field[0] = "username";
                        field[1] = "focusbody";

                        String[] data = new String[2];
                        data[0] = username;
                        data[1] = backbody;

                        PutData putData = new PutData("http://192.168.1.28/calestechsync/createFocusGoal.php/", "POST", field, data);

                        if (putData.startPut()) {
                            if (putData.onComplete()) {
                                String result = putData.getResult();
                                if (result.equals("Focus Goal Created Successfully")) {

                                    Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                                } else {

                                    Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                                }
                            }
                        } else {

                            Toast.makeText(getApplicationContext(), "Failed to connect", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });

        but7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Handler handler = new Handler(Looper.getMainLooper());
                handler.post(new Runnable( ) {
                    @Override
                    public void run() {
                        String[] field = new String[2];
                        field[0] = "username";
                        field[1] = "focusbody";

                        String[] data = new String[2];
                        data[0] = username;
                        data[1] = cardio;

                        PutData putData = new PutData("http://192.168.1.28/calestechsync/createFocusGoal.php/", "POST", field, data);

                        if (putData.startPut()) {
                            if (putData.onComplete()) {
                                String result = putData.getResult();
                                if (result.equals("Focus Goal Created Successfully")) {

                                    Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                                } else {

                                    Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                                }
                            }
                        } else {

                            Toast.makeText(getApplicationContext(), "Failed to connect", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
        Button button = (Button) findViewById(R.id.next);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), goals.class);
                startActivity(intent);
            }
        });

        ImageButton back = (ImageButton) findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), gender.class);
                startActivity(intent);
            }
        });
    }
}