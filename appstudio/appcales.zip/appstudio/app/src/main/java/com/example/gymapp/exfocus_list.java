package com.example.gymapp;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.vishnusivadas.advanced_httpurlconnection.PutData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class exfocus_list extends AppCompatActivity {
    private ListView listView;
    private exfocus_adapter adapter;

    private List<Exercise> exerciseList;
    private String focusbody;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exfocus_list);

        listView = findViewById(R.id.listView);
        exerciseList = new ArrayList<>();

        focusbody = getIntent().getStringExtra("focusbody");

        fetchExercises();
    }

    private void fetchExercises() {
        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Runnable() {
            @Override
            public void run() {
                String[] field = {"focusbody"};
                String[] data = {focusbody};

                PutData putData = new PutData("http://192.168.1.28/calestechsync/getFocusExerciseRecords.php", "POST", field, data);

                if (putData.startPut()) {
                    if (putData.onComplete()) {
                        String result = putData.getResult();

                        if (result != null && !result.isEmpty()) {
                            try {
                                JSONArray jsonArray = new JSONArray(result);
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                                    String exerciseName = jsonObject.getString("exname");
                                    String description = jsonObject.getString("exdesc");
                                    String imageUrl = jsonObject.getString("eximg");
                                    String difficulty = jsonObject.getString("exdifficulty");

                                    Exercise exercise = new Exercise(exerciseName, description, imageUrl, difficulty);
                                    exerciseList.add(exercise);
                                }

                                if (!exerciseList.isEmpty()) {
                                    adapter = new exfocus_adapter(exfocus_list.this, exerciseList);
                                    listView.setAdapter(adapter);
                                } else {
                                    Toast.makeText(exfocus_list.this, "No exercises found", Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                                Toast.makeText(exfocus_list.this, "Error parsing JSON data", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(exfocus_list.this, "Empty or null result received", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(exfocus_list.this, "Failed to complete request", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(exfocus_list.this, "Error sending request", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}
